name=input("Enter String:")
print(name[::-1])
