for x in range(5):
    for i in range(0,x+1):
        print("*",end=" ")
    print() 
