p=int(input("Enter The Value Of P:"))
r=int(input("Enter The Value Of R:"))
n=int(input("Enter The Value Of N:"))

print("The Simple Intrest is:" ,p*r*n/100)

