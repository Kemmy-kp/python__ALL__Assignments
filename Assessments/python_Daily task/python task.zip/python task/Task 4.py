no1=int(input("Enter No 1:"))
no2=int(input("Enter No 2:"))
no3=int(input("Enter No 3:"))

if no1>=no2 and no1>=no3:
    print("LARGEST IS NO 1")

elif no2>=no1 and no2>=no3:
    print("LARGEST IS NO 2")

elif no3>=no1 and no3>=no2:
            
    print("LARGEST IS NO 3")

else:
    print("SMALLEST")


    

