d1={}
n=input("Enter Name:")
p=input("Enter Password:")
d1['name']=n
d1['pass']=p

print(d1)

