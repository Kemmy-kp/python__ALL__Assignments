L1=[1,2,3,4,5,6,7,8,9,11]
even=0
odd=0
for i in L1:
    if (i%2) == 0:
        even +=1
    else:
        odd +=1
    
print("The Even Numbers Are ",even)
print("The Odd Numbers Are",odd)
    
    
