for i in range(0,6):
    print(" "+(5-i)*"*")
