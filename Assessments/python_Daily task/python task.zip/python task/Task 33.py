d1={'email':'pammy2330@gmail.com','pass':'2330'}
user_email=input("Enter Email:")
user_pass=input("Enter Password:")

if user_email == d1['email'] and user_pass == d1['pass']:
    print(True)
else:
    print(False)
    
