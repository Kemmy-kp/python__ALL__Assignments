Number=int(input("Enter Number:"))
for i in range(1,11):
    print(Number,'*',i,'=',Number*i)
    
   
   
