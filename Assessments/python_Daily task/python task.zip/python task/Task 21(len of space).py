value="Duck is a bird. It's Age Is 2 yrs"

count=0

for i in value:
    if i==' ':
        count+=1

print("Length Of Space Is",count)

