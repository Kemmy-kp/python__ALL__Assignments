from tkinter import *
from tkinter import messagebox as msg
root=Tk()
root.title("Welcome To Calculator")
root.geometry('1000x1000')
root.resizable(False,False)


