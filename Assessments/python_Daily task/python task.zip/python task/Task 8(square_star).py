for x in range(5):
    for i in range(5):
        print("*",end=" ")
    print()
