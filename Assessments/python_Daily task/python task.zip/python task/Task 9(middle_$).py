for x in range(5):
    for i in range(5):
        if x==2 and i == 2:
            print("$",end=" ")
        else:
            print("*",end=" ")
    print() 
