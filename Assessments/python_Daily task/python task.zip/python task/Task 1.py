a=int(input("Enter no of Days:"))

print("Number Of Years:",a/365)

print("Number Of Months:",a//30)
