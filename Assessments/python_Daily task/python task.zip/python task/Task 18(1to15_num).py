A=1
for i in range(6):
    for x in range(1,i+1):
        print(A, end=" ")
        A+=1
    print()
   
