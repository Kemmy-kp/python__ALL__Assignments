for x in range(1,6):
    for i in range(1,x+1):
        print(i%2,end=" ")
    print() 
