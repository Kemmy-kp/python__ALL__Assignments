l_var = lambda n: n**0.5

i=int(input("Enter A Num:"))
print(l_var(i))
