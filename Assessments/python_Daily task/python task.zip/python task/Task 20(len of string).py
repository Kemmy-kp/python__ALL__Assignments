value="Duck is a bird. It's Age Is 2 yrs"

count=0
for i in value:
    count+=1
print("Length Of A String:",count)
