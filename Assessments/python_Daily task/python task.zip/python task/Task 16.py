for i in range(5,0,-1):
    print((5-1)* ""+i*"* ")
