'''print multiplication of table'''

num=int(input("enter number:"))
for i in range(1,11):
    print(num, '*', i, '=', num*i)

