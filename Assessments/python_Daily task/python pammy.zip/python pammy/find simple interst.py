P= 5000 #Principal Amount  
R=15 #Rate   
T=1 #Time  
SI  = (P*R*T)/100; # Simple Interest calculation  
print("Simple Interest is :");  
print(SI);  #prints Simple Interest  
