for i in range(1,11):
    print( i,"hello")


'''1 to 10 odd even'''
even=0
odd=0
for i in range(1,11):
    num=int(input("enter number:"))
    
    if(num%2==0):
        even+=1
    else:
        odd+=1
print("enter even num:",even)
print("enter odd num:",odd)







        


    
