#'''take user input in terms of length & brtedth 7 find area of rectangle'''

'''<---area = len*bre'''

print("Enter Length of Rectangle: ")
l = float(input())
print("Enter Breadth of Rectangle: ")
b = float(input())
a = l*b
print("\nArea = ", a)
