#'''take three number input from user & find which one is smallest'''


a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
c = int(input("Enter third number: "))
 
if (a < b) and (a < c):
   smallest = a
elif (b < a) and (b < c):
   smallest = b
else:
   smallest = c
 
print("The largest number is",smallest)
