#calculatar using arithmatic operation method:
#static method:

a=int(input("enter val 1:"))
b=int(input("enter val 2:"))


print("addition is :",a+b)
print("subtract is :",a-b)
print("multiplication is :",a*b)
print("divition is :",a/b)
print("moduls is :",a%b)

#daynamic method:

a=50
b=3

print("the value of",a,"+",b,"is:",a+b)
print("the value of",a,"-",b,"is:",a-b)
print("the value of",a,"*",b,"is:",a*b)
print("the value of",a,"/",b,"is:",a/b)
print("the value of",a,"%",b,"is:",a%b)
print("the value of",a,"//",b,"is:",a//b)
