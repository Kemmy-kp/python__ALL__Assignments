lucky_num=90

status=True
while status:
    
    num=int(input("enter lucky num: "))
    if num==lucky_num:
        print("You won ")
    else:
        print("wrong number guess !!!")

    choice=input("do you want to continue ?['y\n']: ")
    if choice=='y':
        status=True
    else:
        status=False
