#'''task 2: take user input as radius and find area of circle'''

'''Area = pi * r2
<---where r is radius of circle'''

PI = 3.14
r = float(input("Enter the radius of a circle:"))
area = PI * r * r
print("Area of a circle = %.2f" %area)
