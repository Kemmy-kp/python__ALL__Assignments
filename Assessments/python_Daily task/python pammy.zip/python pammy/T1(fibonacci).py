#'''print fibonacci series upto the terms that user wans'''

