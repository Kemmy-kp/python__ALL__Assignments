#'''take height and base from user and find area of triangle'''


print("Enter the Base Length of Triangle: ")
b = float(input())
print("Enter the Height Length Triangle: ")
h = float(input())
a = 0.5 * b * h
print("\nArea = ", a)
